#!/usr/bin/env python3
from pathlib import Path
import argparse, shutil, zipfile, random, urllib.request, yaml

URL = "https://github.com/ultralytics/assets/releases/download/v0.0.0/construction-ppe.zip"
NAMES = {0:"helmet",1:"gloves",2:"vest",3:"boots",4:"goggles",5:"none",6:"Person",7:"no_helmet",8:"no_goggle",9:"no_gloves",10:"no_boots"}
GLOVE_IDS, PPE_IDS = {1,9}, {0,2,3,4,7,8,10}

def parse_label(path):
    ids=set()
    if path.exists():
        for line in path.read_text(errors="ignore").splitlines():
            try: ids.add(int(float(line.split()[0])))
            except (ValueError, IndexError): pass
    return ids

def locate_pairs(root):
    pairs=[]
    for img in root.rglob("*"):
        if img.suffix.lower() not in {".jpg",".jpeg",".png",".webp"}: continue
        parts=list(img.parts)
        if "images" not in parts: continue
        idx=len(parts)-1-parts[::-1].index("images")
        lp=parts[:]; lp[idx]="labels"
        label=Path(*lp).with_suffix(".txt")
        if label.exists(): pairs.append((img,label,parse_label(label)))
    return pairs

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--limit",type=int,default=30)
    ap.add_argument("--out",default="VisionSafe_PPE_Dataset")
    ap.add_argument("--seed",type=int,default=42)
    args=ap.parse_args()
    cwd=Path.cwd(); archive=cwd/"construction-ppe-source.zip"; extract=cwd/"_construction_ppe_source"; out=cwd/args.out
    if not archive.exists():
        print("Downloading public Ultralytics Construction-PPE dataset...")
        urllib.request.urlretrieve(URL,archive)
    if not extract.exists():
        extract.mkdir(parents=True,exist_ok=True)
        with zipfile.ZipFile(archive) as z: z.extractall(extract)
    pairs=locate_pairs(extract)
    if not pairs: raise SystemExit("No YOLO image/label pairs found in archive.")
    gloves=[p for p in pairs if p[2]&GLOVE_IDS]; ppe=[p for p in pairs if p[2]&PPE_IDS]
    rng=random.Random(args.seed); rng.shuffle(gloves); rng.shuffle(ppe)
    chosen={}
    for group,candidates in (("gloves",gloves[:args.limit]),("construction_ppe",ppe[:args.limit])):
        for img,label,ids in candidates: chosen[str(img.resolve())]=(img,label,ids,group)
    records=list(chosen.values()); rng.shuffle(records)
    if out.exists(): shutil.rmtree(out)
    for s in ("train","val","test"):
        (out/"images"/s).mkdir(parents=True,exist_ok=True); (out/"labels"/s).mkdir(parents=True,exist_ok=True)
    n=len(records); nv=max(1,round(n*.1)) if n>=5 else 0; nt=max(1,round(n*.1)) if n>=8 else 0
    split_list=["train"]*(n-nv-nt)+["val"]*nv+["test"]*nt; rng.shuffle(split_list)
    for i,((img,label,ids,group),split) in enumerate(zip(records,split_list),1):
        name=f"vs_{i:04d}_{img.name}"
        shutil.copy2(img,out/"images"/split/name)
        shutil.copy2(label,out/"labels"/split/(Path(name).stem+".txt"))
    data={"path":str(out.resolve()).replace("\\","/"),"train":"images/train","val":"images/val","test":"images/test","names":NAMES}
    (out/"data.yaml").write_text(yaml.safe_dump(data,sort_keys=False),encoding="utf-8")
    (out/"SOURCE_AND_LICENSE.txt").write_text(
        "Source documentation: https://docs.ultralytics.com/datasets/detect/construction-ppe/\\n"
        "Source archive: "+URL+"\\nReview current license and attribution terms before use or redistribution.\\n",
        encoding="utf-8")
    print(f"Created {len(records)} unique annotated images in {out.resolve()}")
    print("Groups can overlap; duplicate images are deduplicated. Labels are original YOLO bounding boxes.")
    print(f'yolo detect train data="{(out/"data.yaml").resolve()}" model=yolo11n.pt epochs=50 imgsz=640')

if __name__=="__main__": main()
